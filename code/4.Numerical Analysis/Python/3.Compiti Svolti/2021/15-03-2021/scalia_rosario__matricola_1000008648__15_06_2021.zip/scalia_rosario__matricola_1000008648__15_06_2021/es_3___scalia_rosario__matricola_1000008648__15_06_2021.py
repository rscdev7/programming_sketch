# -*- coding: utf-8 -*-
"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from matplotlib import pyplot as plt
from math import cos,sin,exp,pi,sqrt,tan


def es_3__newton(f,f_der,x_0,tol,max_iter):
    
    x  = x_0
    i  = 0
    dx = 1.0
    
    while (dx > tol and i < max_iter):
        dx = - f(x)/f_der(x)
        x = x + dx
        i += 1
        
    if (dx < tol):
        print("-> L''approssimazione dello Zero soddisfa la soglia {}".format(tol))
    else:
        print("-> L''approssimazione dello Zero NON soddisfa la soglia {}".format(tol))
        
    return x,f(x),i


def es_3__entry_point():
    print ("\n________ES_3_____")
    f        = lambda a:exp(a)
    g        = lambda a:tan(a)
    aux_f    = lambda a:f(a)-g(a)
    aux_f_1  = lambda a: exp(a) - 1/cos(a)**2
    
    a        = pi/2
    b        = 3*pi/2
    tol      = 10e-8
    n_points = 1000
    step     = 1
    
    
    #Calcolo aux_f(x) for_all x \in points
    points   = np.linspace(a,b,n_points)
    aux_p    = list( map( lambda a:aux_f(a),points))
    

    #Cerco di trovare un sottointervallo di [a,b] dove vale il THM degli Zeri
    extr_zeros     = []
    for i in range(0,n_points-step,step):
        z = aux_f(points[i])
        q = aux_f(points[i+step])
        
        #Verifico Ipotesi THM Zeri
        if (z*q < 0):
            
            if (z < q):
                extr_zeros.append((z,q))
            else:
                extr_zeros.append((q,z))
    
    #Ho due intersezioni
    #Cerco Approx Zero in [-1.6331239353195366e+16, 322.8161569314372]
    #Cerco Approx Zero in [-48.373846404933445, 4.278473947608006]
    x,_,i        = es_3__newton(aux_f,aux_f_1,extr_zeros[0][1],tol,1000)
    x2,_,i2      = es_3__newton(aux_f,aux_f_1,extr_zeros[1][1],tol,1000) 
    print ("\n[!] Il Primo punto di intersezione fra le due curve è: {} - N Iterazioni: {}".format(x,i))
    print ("\n[!] Il Secondo punto di intersezione fra le due curve è: {} - N Iterazioni: {}".format(x2,i2))
    


es_3__entry_point()
