# -*- coding: utf-8 -*-
"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from matplotlib import pyplot as plt
from math import cos,sin,exp,pi,sqrt,tan

def es_2__entry_point():
    #Plot grafico Polinomio
    x = np.array([0.0,3.0])
    y = np.array([1.0,2.0])
    coeff = np.array([4/27,-2/3,1.0,1.0])
        
    p_eval = []
    for i in x:
        v = coeff[0]*i**3 + coeff[1]*i**2 + coeff[2]*i + coeff[3]
        p_eval.append(v)
    
    
    plt.plot(x,p_eval)
    plt.plot(x,y,"or")
    plt.show()
    
    
es_2__entry_point()
