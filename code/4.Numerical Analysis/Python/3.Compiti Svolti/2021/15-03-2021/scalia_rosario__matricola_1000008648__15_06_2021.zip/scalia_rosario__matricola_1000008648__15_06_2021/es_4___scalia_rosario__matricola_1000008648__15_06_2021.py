# -*- coding: utf-8 -*-
"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from matplotlib import pyplot as plt
from math import cos,sin,exp,pi,sqrt,tan

def es_4__trapezi_compositi (f,a,b,N):
    h = (b-a)/N
    T = (f(a)+f(b))/2

    for i in range(N-1):
        p = a + (i+1)*h
        T += f(p)
         
    T = T * h
    
    return T
       
def es_4__entry_point():
    print ("\n________ES_4_____")
    f = lambda a:exp( sin(2*pi*a) )
    a = 0.0
    b = 1.0
    
    N_SUDD = [2**p for p in range(2,6)]
    
    approx_integral_based_on_sudd = [es_4__trapezi_compositi(f,a,b,i) for i in N_SUDD]
    
    for c,i in enumerate(N_SUDD):
        print ("[!] Numero Suddivisione: {} - Approx Integrale: {}\n".format(i,approx_integral_based_on_sudd[c]))
     
             
    exact_integral = 1.266065877752008
    print ("[!] Valore Integrale Esatto: {}\n".format(exact_integral))
    
    #Supponendo di non poter calcolare l'integrale esatto, possiamo usare anche l'estrapolazione per capire l'errore che stiamo commetendo
    diff_2_0 = abs((approx_integral_based_on_sudd[1]-approx_integral_based_on_sudd[0])/3)
    print("[!] Differenza T[4] e T[8]: {} - diff<Tol: {} - Tol: {}\n".format(diff_2_0,diff_2_0<10e-3 , 10e-3))
    
    diff_3_4 = abs((approx_integral_based_on_sudd[2]-approx_integral_based_on_sudd[1])/3)
    print("[!] Differenza T[8] e T[16]: {} - diff<Tol: {} - Tol: {}\n".format(diff_3_4,diff_3_4<10e-8 , 10e-8))
    
    diff_4_5 = abs((approx_integral_based_on_sudd[3]-approx_integral_based_on_sudd[2])/3)
    print("[!] Differenza T[16] e T[32]: {} - diff<Tol: {} - Tol: {}\n".format(diff_4_5,diff_4_5<10e-15 , 10e-15))
    
    
    

es_4__entry_point()