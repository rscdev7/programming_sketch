# -*- coding: utf-8 -*-
"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from matplotlib import pyplot as plt
from math import cos,sin,exp,pi,sqrt,tan
import cmath

def norm2 (x):
    out = [0.0]*len(x)
    for i in range(len(x)):
        out[i] = x[i]**2
    
    sum_out = 0.0
    for i in range(len(x)):
        sum_out += out[i]
    
    norm_2_vec = sqrt(sum_out)
    
    return norm_2_vec
    

def es_1__power_method(A, x_init ,max_iter, tol):
    
    x           = x_init.copy()
    i           = 0
    dim         = len(x)
    check_condition = 1.0
    
    
    while i < max_iter and check_condition > tol:
        
        #Normalizzo Vettore
        x_max = max(x_init)
        y = [0.0]*dim
        for i in range(dim):
            y[i] = x[i]/x_max
            
        #Calcolo A*y 
        for i in range(dim):
            x[i] = 0.0
            for j in range(dim):
                x[i] += A[i][j]*y[j]
                
        #Calcolo Quoziente di Raylength
        yx = 0.0
        yy = 0.0
        
        for i in range(dim):
            yx += y[i] * x[i]
            
        for i in range(dim):
            yy += y[i]*y[i]
            
        autoval_i = yx/yy
        
        
        #Incremento Contatore Iterazioni
        i += 1
        
        
        #Calcolo check qualita approx Autovalore
        
        #Calcolo autoval * y
        autoval_y = [0.0]*dim
        for i in range(dim):
            autoval_y[i] = autoval_i*y[i]
            
        #Calcolo x^k+1 - autoval * y
        x_menus_autoval_y = [0.0]*dim
        for i in range(dim):
            x_menus_autoval_y[i] = x[i] - autoval_y[i]
        
        numerator  = norm2(x_menus_autoval_y)
        denominator = norm2(x)
        
        # ||x_k1 - autoval*y|| / ||x_k1|| < tol ?
        check_condition = numerator/denominator
        
    #Print Superamento soglia
    if (check_condition< tol):
        print ("\n-> L'approssimazione dell'Autovalore di Modulo Massimo Soddisfa la soglia {}".format(tol))
    else:
        print ("\n-> L'approssimazione dell'Autovalore di Modulo Massimo NON Soddisfa la soglia")
    
    
    #Normalizzo Autovettore associato al Raggio spettrale di A
    norm_autovec = [0.0]*dim
    max_autovec  = max(x)
    
    for i in range(dim):
        norm_autovec[i] = x[i]/max_autovec 
        
        
    return autoval_i, norm_autovec,i
 


def es_1__plot_disks(A):
    dim                      = len(A[0])
    
    #Calcolo Raggio Dischi
    R                        = np.zeros(shape=(dim))
    
    for i in range(dim):
        for j in range(dim):
            if (i!=j):
                R[i] += abs(A[i][j])
                
    
    #Calcolo Dischi
    #abs(z-a_ii) < R_i
    K      = []
    
    """
    #Generazione Numeri Complessi
    real_p = np.linspace(0.0,100,1000)
    img_p  = np.linspace(0.0,100,1000)
    c_numbers = list(zip(real_p,img_p))
    c_numbers_ls = []
    for v in c_numbers:
        c_numbers_ls.append(complex(v[0],v[1])
    """
    
    
        
    
            
            
def es_1__entry_point():
    print ("\n________ES_1_____")
    A =             [
                   [8.0 , -2.0, 1.0, 0.0],
                   [-2.0,2.0,-1.0,1.0],
                   [1.0,-1.0,3.0,-1.0],
                   [0.0,1.0,-1.0,-5.0]
                   ]
                   
    x_0     = [1.0,1.0,1.0,1.0]
    
    tol = 10e-4
    max_iter = 100
    
    autoval,autovec,i = es_1__power_method(A,x_0,max_iter,tol)
    print("\n[!] Il raggio spettrale di A è: {}\n\n[!] L'autovettore Normalizzato associato a p(A) è: \n{}\n\n[!] Il numero di iterazioni necessarie per ottenere un approssimazione sotto la soglia è: {}".format(autoval,autovec,i))
    
    spectral_ray_np = np.linalg.eigvals(A)[0]
    print("[!] Numpy Spectral Ray: {}".format(spectral_ray_np))
    
    
    es_1__plot_disks(A)

es_1__entry_point()