"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from math import sin,cos,exp,log,pi,sqrt
from matplotlib import pyplot as plt

f = lambda a,delta: a-(a**2-delta)**(1/2)

delta = 10e-6
a     = 1000

print(f(a,delta))