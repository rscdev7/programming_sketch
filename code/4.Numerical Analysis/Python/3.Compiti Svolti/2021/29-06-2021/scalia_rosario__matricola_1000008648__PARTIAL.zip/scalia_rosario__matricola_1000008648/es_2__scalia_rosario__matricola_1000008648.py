# -*- coding: utf-8 -*-
"""
- Nominativo: Rosario Scalia
- Matricola: 1000008648
"""

import numpy as np
from math import sin,cos,exp,log,pi
from matplotlib import pyplot as plt


def computeNewtonBase (X,Y):
    dim = len(X)
    diff_div = Y.copy()
    
    for i in range(1,dim):
        
        for j in range(dim-1 , i-1, -1):
            diff_div[j]= ( diff_div[j] - diff_div[j-1] )/(X[j] - X[j-i])
            
    return diff_div
    

def evalNewton(p,base,nodes):
    dim = len(nodes)
    
    E = base[dim-1]
    
    for i in range(dim-2,-1,-1):
        E *= (p - nodes[i])
        E += base[i]
        
    return E


def newton_roots (f,f1,max_iter, tol,x0):
    dx = 1.0
    i  = 0
    x  = x0
    
    while (abs(dx) > tol and i < max_iter):
        dx = -f(x)/f1(x)
        x += dx
        i+=1
        
    if (abs(dx) < tol):
        print("[!] Lo Zero trovato soddisfa la soglia")
        
    return x,f(x)
    
    
def bisezione (f, a, b , tol , max_iter):
    i  = 0
    a1 = a
    b1 = b
    mid_p = 0.0
    
    while (i < max_iter):
        i+=1
        mid_p = (a1+b1)/2
        
        if (abs(f(mid_p))<tol):
            print ("-> Trovato Zero Funzione!")
            break
        
        if (f(a1)*f(mid_p)<0):
            a1 = a
            b1 = mid_p
        else:
            a1 = mid_p
            b1 = b
            
            
    return mid_p,f(mid_p)
        

def parte_1 ():
    # PARTE 1 - INTERPOLAZIONE - PUNTI 1-2
    f = lambda x: exp(cos(pi*x))
    
    X = [-1+i/2 for i in range(5)]
    Y = list( map( lambda x:f(x), X ) )
    
    base = computeNewtonBase(X,Y)
    interp_p = list( map( lambda x:evalNewton(x,base,X),X))
        
    plt.plot(X,Y,"or")
    plt.plot(X,interp_p,"b")
    plt.title("Grafico Punti Interpolazione e Polinomio Interpolazione")
    plt.show()


def parte_2():
    # PARTE 2 - PUNTO ALPHA - PUNTI 3-4
    f                = lambda x: exp(cos(pi*x))
    a                = -1.0
    b                = +1.0
    
    #Ricopio la base e i nodi dalla parte 1
    X                = [-1.0, -0.5, 0.0, 0.5, 1.0]
    base             = [0.36787944117144233, 1.2642411176571153, 2.172322539260975, -6.03029990206477, 6.03029990206477]
    
    #Funzione su cui sto cercando alpha
    aux_abs          = lambda x:abs(f(x)-evalNewton(x,base,X))
    
    points           = np.linspace(a,b,1000)
    aux_abs_p        = list( map( lambda x:aux_abs(x),points))
    
    
    #Grafico per capire quanti punti alpha ci sono
    plt.plot(points,aux_abs_p,"g")
    plt.axhline(color="red")
    plt.show()
    
    
    #Grafico per individuare un singolo punto alpha  - Levo valore assoluto se non vale THM Zeri
    aux              = lambda x:f(x)-evalNewton(x,base,X)
    aux_p            = list( map( lambda x:aux(x),points))
    
    #Scelgo Intervallo di un Punto Alpha - Voglio trovare l'alpha uguale a 0.0
    #Quest'ultimo è il terzo nodo di interpolazione del punto precedente
    inf = -0.515392
    sup = -0.499788
    
    plt.plot(points,aux_p,"b")
    plt.plot([inf,sup],[aux(inf),aux(sup)],"or")
    plt.axhline(color="red")
    plt.show()
    
    #Verifico Ipotesi THM degli Zeri
    print("[!] L'intervallo [{},{}] Scelto rispetta il THM degli Zeri ? {}".format( inf,sup,aux(inf)*aux(sup)<0))
    
    #Procedo a trovare lo Zero col Metodo di Bisezione
    tol              = 10e-10
    one_alpha,falpha = bisezione (aux,a,b,10e-10,1000)
    
    print("[!] L'alpha trovato si trova nell'ascissa {} - aux_f(alpha) = {} ".format(one_alpha,falpha))
    
    
parte_1()
parte_2()